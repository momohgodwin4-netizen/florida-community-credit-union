# Florida Community Credit Union — Fictional Production-Style Banking UI

This package is a standalone, polished banking dashboard built from the supplied `app.js` concept.

IMPORTANT:
- This is a fictional institution and test environment.
- It is not connected to Florida Credit Union or any other financial institution.
- No real money, bank credentials, card data, or authentication are processed.
- Before any legitimate deployment, replace the test data and simulated actions with an authorized banking/core-banking integration, approved identity provider, security controls, compliance requirements, audit logging, and server-side authorization.

## Run
Open `index.html` in a modern browser.

For a local server:
  python -m http.server 8080

Then visit:
  http://localhost:8080

## Included
- Responsive banking dashboard
- Overview and account summaries
- Transaction search/filter
- CSV export
- Test transfers, bill pay, and send-money flows
- Analytics
- Security center
- Settings
- Dark mode
- Mobile navigation
- Modal and toast interactions
- Persistent theme preference

The UI intentionally contains an environment banner so it cannot reasonably be mistaken for a live financial institution portal.
