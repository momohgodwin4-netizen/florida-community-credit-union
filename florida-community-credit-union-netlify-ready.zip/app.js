const state = {
  page: "overview",
  theme: localStorage.getItem("fccu-theme") || "light",
  transactions: [
    ["Blue Bottle Coffee","Sep 16, 2026","Dining","-$6.80"],
    ["Demo Corp Payroll","Sep 15, 2026","Income","+ $4,850.00"],
    ["Whole Foods Market","Sep 14, 2026","Groceries","-$82.41"],
    ["City Ride","Sep 13, 2026","Transport","-$18.50"],
    ["Streamly","Sep 12, 2026","Subscriptions","-$12.99"],
    ["Transfer from Savings","Sep 10, 2026","Transfer","+ $500.00"]
  ]
};
const page = document.querySelector("#page"), toast = document.querySelector("#toast");

function money(n){return n.toLocaleString("en-US",{style:"currency",currency:"USD"});}
function showToast(msg){toast.textContent=msg;toast.classList.add("show");setTimeout(()=>toast.classList.remove("show"),2400)}
function modal(html){document.querySelector("#modal").innerHTML=html;document.querySelector("#modalBackdrop").hidden=false}
function closeModal(){document.querySelector("#modalBackdrop").hidden=true}
function setPage(p){state.page=p;document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===p));render();document.querySelector("#sidebar").classList.remove("open")}
function render(){
  const pages={overview:overview,transactions:transactions,payments:payments,analytics:analytics,security:security,settings:settings};
  page.innerHTML=pages[state.page]();
  bindPageActions();
}
function overview(){return `
<div class="page-head"><div><h1>Good morning, Jordan</h1><div class="muted">Wednesday, September 17, 2026 · Test account</div></div><div class="actions"><button class="btn secondary" data-action="statement">View statement</button><button class="btn primary" data-action="transfer">Transfer</button></div></div>
<div class="notice">This is a fictional banking application for testing and presentation. It is not connected to a financial institution.</div>
<div class="grid grid-4">
 <div class="card balance-card"><div class="stat-label">Total available</div><div class="balance">$24,680.42</div><div class="muted">Checking •••• 4821</div></div>
 <div class="card"><div class="stat-label">Checking</div><div class="stat">$18,430.42</div><div class="muted">Available balance</div></div>
 <div class="card"><div class="stat-label">Savings</div><div class="stat">$6,250.00</div><div class="muted">Goal: emergency fund</div></div>
 <div class="card"><div class="stat-label">September spending</div><div class="stat">$2,184.00</div><div class="muted">12% below last month</div></div>
</div><div class="grid grid-2" style="margin-top:18px">
 <div class="card"><div class="card-head"><h2>Recent activity</h2><button class="btn secondary" data-page="transactions">View all</button></div>${txRows(state.transactions.slice(0,5))}</div>
 <div class="card"><div class="card-head"><h2>Monthly cash flow</h2><span class="muted">Sep 2026</span></div><div class="bar-chart">${[72,45,82,55,64,90,67,78,51,86,70,94].map(v=>`<div class="bar" style="height:${v}%"></div>`).join("")}</div><div class="bar-labels">${["W1","W2","W3","W4",""].map(x=>`<span>${x}</span>`).join("")}</div></div>
</div>`}
function txRows(items){return `<div class="list">${items.map(t=>`<div class="row"><div class="tx-icon">${t[0][0]}</div><div class="row-main"><strong>${t[0]}</strong><small>${t[1]} · ${t[2]}</small></div><div class="amount ${t[3].includes("+")?"positive":"negative"}">${t[3]}</div></div>`).join("")}</div>`}
function transactions(){return `<div class="page-head"><div><h1>Transactions</h1><div class="muted">Review activity on your fictional test accounts.</div></div><button class="btn secondary" data-action="export">Export CSV</button></div><div class="card"><div class="searchbar"><input id="txSearch" placeholder="Search merchant or category…"><select id="txFilter"><option>All transactions</option><option>Income</option><option>Spending</option><option>Transfer</option></select></div><div id="txTable">${txTable(state.transactions)}</div></div>`}
function txTable(items){return `<div class="table-wrap"><table class="table"><thead><tr><th>Description</th><th>Date</th><th>Category</th><th>Amount</th></tr></thead><tbody>${items.map(t=>`<tr><td><strong>${t[0]}</strong></td><td>${t[1]}</td><td>${t[2]}</td><td class="${t[3].includes("+")?"positive":"negative"}"><strong>${t[3]}</strong></td></tr>`).join("")}</tbody></table></div>`}
function payments(){return `<div class="page-head"><div><h1>Payments & Transfers</h1><div class="muted">Create test transactions without moving real money.</div></div></div><div class="grid grid-3"><div class="card"><div class="card-head"><h2>Transfer money</h2></div><p class="muted">Move fictional funds between your test accounts.</p><button class="btn primary" data-action="transfer">Start transfer</button></div><div class="card"><div class="card-head"><h2>Pay a bill</h2></div><p class="muted">Schedule a simulated bill payment.</p><button class="btn primary" data-action="bill">Create payment</button></div><div class="card"><div class="card-head"><h2>Send money</h2></div><p class="muted">Send a test payment to a fictional recipient.</p><button class="btn primary" data-action="send">Send test payment</button></div></div><div class="card" style="margin-top:18px"><div class="card-head"><h2>Scheduled activity</h2><span class="muted">0 pending</span></div><div class="empty">No scheduled test payments.</div></div>`}
function analytics(){return `<div class="page-head"><div><h1>Analytics</h1><div class="muted">A presentation view of fictional account activity.</div></div></div><div class="grid grid-3"><div class="card"><div class="stat-label">Income</div><div class="stat positive">$6,240</div><div class="muted">This month</div></div><div class="card"><div class="stat-label">Spending</div><div class="stat negative">$2,184</div><div class="muted">This month</div></div><div class="card"><div class="stat-label">Net cash flow</div><div class="stat">$4,056</div><div class="muted">Income minus spending</div></div></div><div class="card" style="margin-top:18px"><div class="card-head"><h2>Spending by category</h2></div>${[["Housing",920],["Groceries",482],["Transport",246],["Dining",214],["Subscriptions",122],["Other",200]].map(x=>`<div style="margin:15px 0"><div style="display:flex;justify-content:space-between"><strong>${x[0]}</strong><span>${money(x[1])}</span></div><div style="height:9px;background:var(--surface2);border-radius:9px;margin-top:6px"><div style="height:100%;width:${x[1]/920*100}%;background:var(--primary);border-radius:9px"></div></div></div>`).join("")}</div>`}
function security(){return `<div class="page-head"><div><h1>Security Center</h1><div class="muted">Production-style security UX; authentication is not connected.</div></div></div><div class="card"><div class="security"><div class="check">✓</div><div><strong>Password</strong><div class="muted">Last changed 28 days ago</div></div><button class="btn secondary" data-action="password" style="margin-left:auto">Change</button></div><div class="security"><div class="check">✓</div><div><strong>Multi-factor authentication</strong><div class="muted">Enabled for this test profile</div></div><button class="btn secondary" data-action="mfa" style="margin-left:auto">Manage</button></div><div class="security"><div class="check">✓</div><div><strong>Device monitoring</strong><div class="muted">2 trusted test devices</div></div><button class="btn secondary" data-action="devices" style="margin-left:auto">Review</button></div></div><div class="card" style="margin-top:18px"><h2>Important</h2><p class="muted">No credentials are transmitted or verified by this standalone front end. Connect an authorized identity provider before production use.</p></div>`}
function settings(){return `<div class="page-head"><div><h1>Settings</h1><div class="muted">Manage your fictional test profile.</div></div></div><div class="grid grid-2"><div class="card"><h2>Profile</h2><div class="form-grid" style="margin-top:15px"><div class="field"><label>Display name</label><input value="Jordan Davis"></div><div class="field"><label>Email</label><input value="jordan@example.test"></div><button class="btn primary" data-action="save">Save changes</button></div></div><div class="card"><h2>Preferences</h2><div class="row"><div class="row-main"><strong>Dark mode</strong><small>Change the dashboard appearance</small></div><button class="btn secondary" data-action="theme">Toggle</button></div><div class="row"><div class="row-main"><strong>Notifications</strong><small>Security and account alerts</small></div><button class="btn secondary" data-action="notify">Enabled</button></div></div></div>`}

function formModal(title,body,submit){
  modal(`<h2>${title}</h2><div class="form-grid">${body}</div><div class="modal-actions"><button class="btn secondary" data-close>Cancel</button><button class="btn primary" id="modalSubmit">${submit}</button></div>`);
  document.querySelector("#modalSubmit").onclick=()=>{closeModal();showToast("Test action completed — no real money moved.");};
}
function bindPageActions(){
  document.querySelectorAll("[data-page]").forEach(b=>b.onclick=()=>setPage(b.dataset.page));
  document.querySelectorAll("[data-action]").forEach(b=>b.onclick=()=>action(b.dataset.action));
  const s=document.querySelector("#txSearch"), f=document.querySelector("#txFilter");
  if(s){const update=()=>{let q=s.value.toLowerCase(),filter=f.value;let arr=state.transactions.filter(t=>(t[0]+" "+t[2]).toLowerCase().includes(q)).filter(t=>filter==="All transactions"||((filter==="Income")?t[3].includes("+"):(filter==="Transfer"?t[2]==="Transfer":!t[3].includes("+")&&!["Transfer"].includes(t[2]))));document.querySelector("#txTable").innerHTML=txTable(arr)};s.oninput=update;f.onchange=update}
}
function action(a){
  if(a==="transfer") formModal("New test transfer",`<div class="field"><label>From</label><select><option>Checking •••• 4821</option><option>Savings •••• 9082</option></select></div><div class="field"><label>To</label><select><option>Savings •••• 9082</option><option>Checking •••• 4821</option></select></div><div class="field"><label>Amount</label><input type="number" min="0.01" step=".01" placeholder="0.00"></div>`,"Review transfer");
  if(a==="bill"||a==="send") formModal(a==="bill"?"New test bill payment":"Send test payment",`<div class="field"><label>Recipient</label><input placeholder="Fictional recipient"></div><div class="field"><label>Amount</label><input type="number" min=".01" step=".01" placeholder="0.00"></div><div class="field"><label>Memo</label><input placeholder="Optional memo"></div>`,"Review");
  if(["password","mfa","devices"].includes(a)) formModal("Security settings",`<div class="notice">This control is part of the interface only. Connect an authorized identity provider for real authentication.</div>`,"Continue");
  if(a==="statement")showToast("Statement preview opened — fictional data only.");
  if(a==="export"){const csv="Description,Date,Category,Amount\n"+state.transactions.map(t=>t.join(",")).join("\n");const blob=new Blob([csv],{type:"text/csv"}),url=URL.createObjectURL(blob),x=document.createElement("a");x.href=url;x.download="test-transactions.csv";x.click();URL.revokeObjectURL(url);showToast("CSV exported.");}
  if(a==="support")showToast("Support center is available in the test environment.");
  if(a==="save")showToast("Profile changes saved locally.");
  if(a==="theme")toggleTheme();
  if(a==="notify")showToast("Notification preference unchanged in test mode.");
}
document.querySelector("#menuBtn").onclick=()=>document.querySelector("#sidebar").classList.toggle("open");
document.querySelector("#themeBtn").onclick=toggleTheme;
document.querySelector("#notifBtn").onclick=()=>showToast("You have 3 test notifications.");
document.querySelector("#modalBackdrop").onclick=e=>{if(e.target.id==="modalBackdrop")closeModal()};
document.addEventListener("click",e=>{if(e.target.matches("[data-close]"))closeModal()});
function toggleTheme(){state.theme=state.theme==="dark"?"light":"dark";document.body.classList.toggle("dark",state.theme==="dark");localStorage.setItem("fccu-theme",state.theme)}
document.body.classList.toggle("dark",state.theme==="dark");render();
