# Netlify deployment

## Fastest method
1. Create/log into a Netlify account.
2. Go to Netlify Drop.
3. Upload this entire folder.
4. Netlify will publish it at a `netlify.app` URL.
5. Use the Netlify project settings to customize the project name or attach a domain you own.

## Git deployment
Put this folder in a GitHub repository, then in Netlify choose **Add new project → Import an existing project**, select the repository, and publish it. Future pushes can trigger deployments.

## Important
This is a fictional banking-style interface. It is not connected to Florida Credit Union or any financial institution and does not process real credentials or money.
